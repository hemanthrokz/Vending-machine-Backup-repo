package com.VendingMachine.VendingMachine01.controller;


import com.VendingMachine.VendingMachine01.dto.CustomerInputDTO;
import com.VendingMachine.VendingMachine01.dto.InventoryDTO;
import com.VendingMachine.VendingMachine01.dto.VendingMachineOutputDTO;
import com.VendingMachine.VendingMachine01.model.Inventry;
import com.VendingMachine.VendingMachine01.service.RestTemplateService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/RestTemplate")
public class RestTemplateController {

    @Autowired
    private RestTemplateService restTemplateService;


    @GetMapping("/getAllProduct")
    public ResponseEntity<String> getAllProduct(){
    return restTemplateService.allProduct();
    }

    @PostMapping("/addProduct")
    public ResponseEntity<Inventry> addProduct(@RequestBody Inventry inventoryDTO){
        return restTemplateService.addProduct(inventoryDTO);
    }

    @GetMapping("/getProduct/{id}")
    public Inventry getProductById(@PathVariable int id){
        return restTemplateService.getProductById(id);
    }

    @PutMapping("/updateProduct/{id}")
    public String updateProductById(@RequestBody Inventry e,@PathVariable int id){
         restTemplateService.updateProductById(e,id);
         return "updated !!";
    }

    @DeleteMapping("/products/{id}")
    @Operation(summary = "RestTemplate PROCESS--DELETE  Inventory item ")
    public String deleteProductById(@PathVariable int id) {
         restTemplateService.deleteProductById(id) ;
        return " Product deleted from the database";
    }

}
