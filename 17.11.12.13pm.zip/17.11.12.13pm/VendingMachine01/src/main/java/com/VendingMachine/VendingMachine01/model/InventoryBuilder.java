package com.VendingMachine.VendingMachine01.model;

public class InventoryBuilder {
    private int productId;
    private  String name;
    private  int productPrice;
    private  int productInventryCount;

    public InventoryBuilder() {
    }

    public InventoryBuilder setProductId(int productId) {
        this.productId = productId;
        return this;
    }

    public InventoryBuilder setName(String name) {
        this.name = name;
        return this;
    }

    public InventoryBuilder setProductPrice(int productPrice) {
        this.productPrice = productPrice;
        return this;
    }

    public InventoryBuilder setProductInventryCount(int productInventryCount) {
        this.productInventryCount = productInventryCount;
        return this;
    }

    public Inventry getInventry()
    {
        return new Inventry( productId,  name,  productPrice,  productInventryCount);
    }
}
