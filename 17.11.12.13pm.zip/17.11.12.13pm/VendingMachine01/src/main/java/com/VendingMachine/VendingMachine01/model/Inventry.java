package com.VendingMachine.VendingMachine01.model;


import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public  class Inventry {

    public int productId;
    @NotBlank
    public   String name;
    @NotNull
    @Size(min = 0, max = 50)
    public  int productPrice;
    @NotNull
    @Size(min = 0, max = 20)
    public  int productInventryCount;


    public Inventry() {
    }

    public Inventry(int productId, String name, int productPrice, int productInventryCount) {
        this.productId = productId;
        this.name = name;
        this.productPrice = productPrice;
        this.productInventryCount = productInventryCount;

    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public  String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public  int getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(int productPrice) {
        this.productPrice = productPrice;
    }

    public  int getProductInventryCount() {
        return productInventryCount;
    }

    public void setProductInventryCount(int productInventryCount) {
        this.productInventryCount = productInventryCount;
    }




}
