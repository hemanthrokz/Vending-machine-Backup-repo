package com.VendingMachine.VendingMachine01.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

//class for only input parameters
public class CustomerInputDTO {
    @NotNull
    private int productId;
    @NotNull
    @Size(min = 0, max = 50)
    private int price;

    public CustomerInputDTO() {
    }

    public CustomerInputDTO(CustomerInputDTOBuilder customerInputDTOBuilder) {
        this.productId = productId;
        this.price = price;
    }

    public int getProductId() {
        return productId;
    }


    public int getPrice() {
        return price;
    }


    public static class CustomerInputDTOBuilder {
        private int productId;
        private int price;

        public CustomerInputDTOBuilder() {
        }
@JsonCreator
        public CustomerInputDTOBuilder(@JsonProperty("Inventory_Item_Code") int productId,@JsonProperty("Input_price") int price) {
            this.productId = productId;
            this.price = price;
        }

        public CustomerInputDTOBuilder productId(int productId) {
            this.productId = productId;
            return this;
        }


        public CustomerInputDTOBuilder price(int price) {
            this.price = price;
            return this;
        }

        public CustomerInputDTO build() {
            return new CustomerInputDTO(this);
        }
    }
}