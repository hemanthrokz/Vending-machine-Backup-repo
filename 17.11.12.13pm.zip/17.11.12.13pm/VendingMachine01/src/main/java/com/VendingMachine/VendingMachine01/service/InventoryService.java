package com.VendingMachine.VendingMachine01.service;

import com.VendingMachine.VendingMachine01.customeexception.InsufficientInitialBalanceException;
import com.VendingMachine.VendingMachine01.customeexception.InsufficientInputCashException;
import com.VendingMachine.VendingMachine01.customeexception.ProductIdNotFoundException;
import com.VendingMachine.VendingMachine01.customeexception.ProductUnavialableException;
import com.VendingMachine.VendingMachine01.dao.InitialBalanceDAOImp;
import com.VendingMachine.VendingMachine01.dao.InventoryDAOImp;
import com.VendingMachine.VendingMachine01.dto.CustomerInputDTO;
import com.VendingMachine.VendingMachine01.dto.InventoryDTO;
import com.VendingMachine.VendingMachine01.dto.VendingMachineOutputDTO;
import com.VendingMachine.VendingMachine01.model.InitialBalanceAndPurchaseHistory;
import com.VendingMachine.VendingMachine01.model.InventoryBuilder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class InventoryService {

    InventoryDAOImp repository;

    InitialBalanceDAOImp initialBalanceDAOImp;

    public InventoryService(InventoryDAOImp repository, InitialBalanceDAOImp initialBalanceDAOImp) {
        this.repository = repository;
        this.initialBalanceDAOImp = initialBalanceDAOImp;
    }
/////////////////////////////////////////////////////
private static Logger log = LoggerFactory.getLogger(InventoryService.class);
    ////////////////////////////////////////////////////

    public List<InventoryDTO> getListOfAllInventory(){

        return allProductToUserInventory(repository.findAll());
    }

    public List<InventoryDTO> allProductToUserInventory(List<InventoryBuilder> allInvProduct){
        return  allInvProduct.stream().map(this::productToUserProduct).collect(Collectors.toList());
    }

    public InventoryDTO getProductById(int productId){
        if(repository.findById(productId).isEmpty()){
            throw new ProductIdNotFoundException("invalid product id given in url ....!!!!");
        }else if (repository.findById(productId).get(0).getInventry().getProductInventryCount() < 1) {
            throw new ProductUnavialableException(repository.findById(productId).get(0).getInventry().getName() + " is Out of Stock..!!");
        }
        return productToUserProduct(repository.findById(productId).get(0));
    }

    public InventoryDTO productToUserProduct(InventoryBuilder inventoryBuilder){
        return new InventoryDTO(inventoryBuilder.getInventry().getProductId(),inventoryBuilder.getInventry().getName(),inventoryBuilder.getInventry().getProductPrice(),inventoryBuilder.getInventry().getProductInventryCount());
    }

    //to purchase the product method

    public VendingMachineOutputDTO purchaseProduct(CustomerInputDTO customerInputDTO) {
        int productId = customerInputDTO.getProductId();
        int inputPrice = customerInputDTO.getPrice();
        getProductById(productId);
        InventoryBuilder inventoryBuilder = repository.findById(productId).get(0);
        if (inputPrice < inventoryBuilder.getInventry().getProductPrice()) {
            throw new InsufficientInputCashException(inputPrice + " rupees is not enough for " + inventoryBuilder.getInventry().getName());
        }
        int change = inputPrice  - inventoryBuilder.getInventry().getProductPrice();

        if (initialBalanceDAOImp.getChange().getInitialBalance()< change) {
            throw new InsufficientInitialBalanceException("Sorry No Change!!");
        }
        ///operation to have new initial balance
        //changed to logging insted of standard sysout statement

        log.info("change amount for the purchase == {} ",change);

        int newInitialBalance = initialBalanceDAOImp.getChange().getInitialBalance() - change;

        log.info("new balance in the vending machine == {}",newInitialBalance);

        ///creating new object to populate the initial balance table and the record table
        InitialBalanceAndPurchaseHistory currentTransaction = new InitialBalanceAndPurchaseHistory(0, inventoryBuilder.getInventry().getProductId(), inventoryBuilder.getInventry().getName(), inventoryBuilder.getInventry().getProductPrice(), inputPrice, change, newInitialBalance);

       //calling update stock method form the inventorydaoimplementation class
        repository.updatedStock(inventoryBuilder.getInventry().getProductId(), inventoryBuilder.getInventry().getProductInventryCount() - 1);
        initialBalanceDAOImp.saveTransaction(currentTransaction);
       // initialBalanceDAOImp.updateChange(initialBalanceDAOImp.saveTransaction(currentTransaction));
        return new VendingMachineOutputDTO(inventoryBuilder.getInventry().getName(), inventoryBuilder.getInventry().getProductPrice(), change);

    }


//    public int saveInventory(Inventry inventry){ return repository.save(inventry); }
//
//    public int updateInventory(Inventry inventry,int productId){
//        return repository.update(inventry,productId);
//    }
//
//    public int deleteProductById(int productId){
//        return repository.deleteById(productId);
//    }

    ///////////////////////////////////////////////

}
