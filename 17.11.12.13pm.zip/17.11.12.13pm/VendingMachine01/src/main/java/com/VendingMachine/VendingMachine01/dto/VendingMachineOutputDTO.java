package com.VendingMachine.VendingMachine01.dto;

public class VendingMachineOutputDTO {

    private final String item;
    private final int price;
    private final int balance;

    public VendingMachineOutputDTO(String item, int price, int balance) {
        this.item = item;
        this.price = price;
        this.balance = balance;
    }

    public String getItem() {
        return item;
    }

    public int getPrice() {
        return price;
    }

    public int getBalance() {
        return balance;
    }

}
