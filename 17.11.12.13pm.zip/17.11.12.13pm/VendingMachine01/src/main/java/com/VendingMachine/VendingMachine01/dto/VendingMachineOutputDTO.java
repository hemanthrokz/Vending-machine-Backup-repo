package com.VendingMachine.VendingMachine01.dto;

public class VendingMachineOutputDTO {

    private String item;
    private int price;
    private int balance;

    public VendingMachineOutputDTO(String item, int price, int balance) {
        this.item = item;
        this.price = price;
        this.balance = balance;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }
}
