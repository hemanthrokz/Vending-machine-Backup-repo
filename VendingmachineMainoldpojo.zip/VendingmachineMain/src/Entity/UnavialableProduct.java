package Entity;

public class UnavialableProduct extends RuntimeException {  ///US RUNTIME EXCEPTIONS
    UnavialableProduct(String message){
        super(message);
    }
}
