package com.vendingmachine.WebConsuming.controller;

import com.vendingmachine.WebConsuming.model.Inventory;
import com.vendingmachine.WebConsuming.service.RestTemplateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class RestTemplateController {

    @Autowired
    private RestTemplateService restTemplateService;


    @GetMapping("/getAllProduct")
    public ResponseEntity<String> getAllProduct(){
        return restTemplateService.allProduct();
    }

    @PostMapping("/addProduct")
    public ResponseEntity<Inventory> addProduct(@RequestBody Inventory inventoryDTO){
        return restTemplateService.addProduct(inventoryDTO);
    }

    @GetMapping("/getProduct/{id}")
    public Inventory getProductById(@PathVariable int id){
        return restTemplateService.getProductById(id);
    }

    @PutMapping("/updateProduct/{id}")
    public String updateProductById(@RequestBody Inventory e, @PathVariable int id){
        restTemplateService.updateProductById(e,id);
        return "updated !!";
    }

    @DeleteMapping("/products/{id}")
    public String deleteProductById(@PathVariable int id) {
        restTemplateService.deleteProductById(id) ;
        return " Product deleted from the database";
    }

}
