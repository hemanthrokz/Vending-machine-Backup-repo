package com.vendingmachine.WebConsuming.service;

import com.vendingmachine.WebConsuming.model.Inventory;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Service
public class RestTemplateService {

    private static final String GET_ALL_ITEMS_API="http://localhost:8080/";
    private static final String CREATE_PRODUCT_API="http://localhost:8080/products";
    private static final String GET_PRODUCT_BY_ID_API="http://localhost:8080/product/{id}";
    private static final String UPDATE_PRODUCT_BY_ID_API="http://localhost:8080/productsput/{id}";
    private static final String DELETE_PRODUCT_BY_ID_API="http://localhost:8080/products/{id}";
    private static final String PURCHASE_PRODUCT_BY_ID_API="http://localhost:8080/product";

    RestTemplate restTemplate=new RestTemplate();

    public ResponseEntity<String> allProduct(){
        HttpHeaders headers=new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity=new HttpEntity<String>("parameters",headers);
        ResponseEntity<String> response= restTemplate.exchange(GET_ALL_ITEMS_API, HttpMethod.GET,entity, String.class);
        return response;
    }

    public ResponseEntity<Inventory> addProduct(Inventory inventoryDTO){
        return restTemplate.postForEntity(CREATE_PRODUCT_API,inventoryDTO,Inventory.class);
    }

    public Inventory getProductById(int id){
        Map<String,Integer> param=new HashMap<String, Integer>();
        param.put("id",id);
        return restTemplate.getForObject(GET_PRODUCT_BY_ID_API,Inventory.class,param);
    }

    public void updateProductById(Inventory inventry,int id){
        Map<String,Integer> param=new HashMap<String, Integer>();
        param.put("id",id);
        restTemplate.put(UPDATE_PRODUCT_BY_ID_API,inventry,param);
    }

    public void deleteProductById(int id) {
        Map<String,Integer> param=new HashMap<String, Integer>();
        param.put("id",id);
        restTemplate.delete(DELETE_PRODUCT_BY_ID_API,param);
    }
    public Inventory purchaseProduct(int id){
        Map<String,Integer> param=new HashMap<String, Integer>();
        param.put("id",id);
        return restTemplate.getForObject(PURCHASE_PRODUCT_BY_ID_API,Inventory.class,param);
    }
}
